<!-- Begin

// NOTE: If you use a ' add a slash before it like thi
/*document.write('<DIV id="menulocation">');
document.write('<TABLE cellpadding=0 cellspacing=0 border=0 width="154"><tr><td>');
document.write('<img src="picts/menu-top.gif" width="154" height="120"></a><br>');



// COPY AND PASTE THE NEXT TWO LINES TOO ADD A NEW LINK

document.write('</td></tr><tr><td nowrap>');
document.write('<a href="index.html" class="menu">Home</a>');

document.write('</td></tr><tr><td nowrap>');
document.write('<a href="properties.htm" class="menu">Mining Projects</a>');


document.write('</td></tr><tr><td nowrap>');
document.write('<a href="news.htm" class="menu">News</a>');


document.write('</td></tr><tr><td nowrap>');
document.write('<a href="stock.html" class="menu">Stock Quote</a>');


document.write('</td></tr><tr><td nowrap>');
document.write('<a href="gallery.htm" class="menu">Photo Gallery</a>');


document.write('</td></tr><tr><td nowrap>');
document.write('<a href="about.htm" class="menu">People </a>');


document.write('</td></tr><tr><td nowrap>');
document.write('<a href="mexico.htm" class="menu">Mexican Focus</a>');

document.write('</td></tr><tr><td nowrap>');
document.write('<a href="fact.html" class="menu">Fact Sheet</a>');

document.write('</td></tr><tr><td nowrap>');
document.write('<a href="financial.html" class="menu">Financial</a>');

document.write('</td></tr><tr><td nowrap>');
document.write('<a href="contact.htm" class="menu">Contact</a>');

document.write('</td></tr><tr><td>');
document.write('<img src="picts/menu-bottom.gif" width="154" height="65"></a><br>');
document.write('</td></tr></table></DIV>');
*/
//  End -->
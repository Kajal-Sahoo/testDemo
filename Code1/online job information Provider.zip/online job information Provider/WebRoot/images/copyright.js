<!-- Begin



<!-- NOTE: If you use a ' add a slash before it like this \' -->



document.write('<span class ="copyright">&copy;Copyright 2005 ');

document.write('<a href="index.html" target="_top">Soltoro Ltd.</a> ');

document.write('All Rights Reserved<br>');
document.write('For more information feel free to '); 

document.write(' <A HREF="mailto:contact@soltoro.com">Contact Us</a>');

document.write('</span><br>');
//  End -->
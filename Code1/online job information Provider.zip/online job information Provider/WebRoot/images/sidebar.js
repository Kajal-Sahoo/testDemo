<!-- Begin

/*document.write('<div id="sidebar"><TABLE cellpadding="1" cellspacing="0" border="0" bordercolor="#909099" style="border-collapse: collapse" width="125" background="picts/background-sidebar.jpg"><tr><td align="center">');
document.write('<span class="subtitle">');
document.write('DRILL PROJECTS:<BR>');
document.write('</span>');
document.write('');

document.write('<br>');

document.write('</span>');

document.write('<a href="rayo.htm"><img src="picts/topics-2.jpg" vspace="3" height="50" width="100"><br>');

document.write('<span class="subtitle">');

document.write('EL RAYO<BR>');

document.write('<br>');

document.write('</span>');

document.write('<a href="Bacanora.htm"><img src="picts/Bacanorageo.jpg" vspace="3" height="50" width="100"><br>'); 

document.write('<span class="subtitle">');

document.write('BACANORA<BR>')
;
document.write('<br>');



document.write('</span>');

document.write('<a href="tortuga.htm"><img src="picts/topics-1.jpg" vspace="3" height="50" width="100"><br>');

document.write('<span class="subtitle">');

document.write('LA TORTUGA<BR>');

document.write('<br>');



document.write('</span>');

document.write('<a href="quilla.htm"><img src="picts/ssv.jpg" vspace="3" height="50" width="100"><br>');

document.write('<span class="subtitle">');

document.write('QUILA<BR>');

document.write('<br>');

document.write('<IMG SRC="picts/spacer.gif" HEIGHT="0" WIDTH="100" border="0" alt="image"><BR>');

document.write('</td></tr></table></div>');
*/
//  End -->